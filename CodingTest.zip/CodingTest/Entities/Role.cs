namespace CodingTest.Entities
{
    public class Role
    {
        public int RoleId { get; set; }

        public string Name { get; set; }
    }
}