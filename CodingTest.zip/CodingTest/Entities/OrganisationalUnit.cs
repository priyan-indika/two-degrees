namespace CodingTest.Entities
{
    public class OrganisationalUnit
    {
        public int OrganisationalUnitId { get; set; }

        public string Name { get; set; }
    }
}