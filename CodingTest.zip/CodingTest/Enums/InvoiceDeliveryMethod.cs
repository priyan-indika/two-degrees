﻿namespace CodingTest.Enums
{
    public enum InvoiceDeliveryMethod
    {
        Paper,
        Email,
        Text
    }
}
