namespace CodingTest.Controllers.ViewModels
{
    public class AccountCreatedVm
    {
        public int AccountId { get; set; }
    }
}